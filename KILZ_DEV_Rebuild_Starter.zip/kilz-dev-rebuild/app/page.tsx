'use client';

import { useState } from 'react';

type Task = { id: number; title: string; subject: string; done: boolean };

export default function Home() {
  const [active, setActive] = useState('Ringkasan');
  const [tasks, setTasks] = useState<Task[]>([
    { id: 1, title: 'Rangkum materi yang dipelajari', subject: 'IPS', done: false },
    { id: 2, title: 'Selesaikan latihan matematika', subject: 'Matematika', done: false },
  ]);
  const [newTask, setNewTask] = useState('');
  const [focusOn, setFocusOn] = useState(false);
  const [note, setNote] = useState('');
  const nav = ['Ringkasan', 'Tugas & Jadwal', 'Catatan', 'Focus Mode'];
  const completed = tasks.filter(t => t.done).length;

  function addTask() {
    const title = newTask.trim();
    if (!title) return;
    setTasks(old => [...old, { id: Date.now(), title, subject: 'Umum', done: false }]);
    setNewTask('');
  }

  return <main className="shell">
    <aside className="sidebar">
      <a className="brand" href="#home"><span className="brand-mark">K</span><span>KILZ <b>DEV</b><small>STUDY SPACE</small></span></a>
      <div className="nav-label">WORKSPACE</div>
      <nav>{nav.map(item => <button key={item} className={`nav-item ${active === item ? 'selected' : ''}`} onClick={() => setActive(item)}><span className="nav-dot">{item === 'Ringkasan' ? '◫' : item === 'Tugas & Jadwal' ? '☷' : item === 'Catatan' ? '▤' : '◷'}</span>{item}</button>)}</nav>
      <div className="sidebar-bottom"><div className="status-dot"/> Ruang belajar pribadi <small>Versi awal · 0.1</small></div>
    </aside>
    <section className="content" id="home">
      <header className="topbar"><div><span className="eyebrow">KILZ DEV / STUDY</span><h1>{active}</h1></div><div className="profile"><span className="avatar">K</span><span><b>Pengguna</b><small>Mode lokal</small></span></div></header>
      {active === 'Ringkasan' && <>
        <section className="welcome"><div><p className="eyebrow">RUANG BELAJAR DIGITAL</p><h2>Pelan-pelan, yang penting<br/>ada progres.</h2><p className="muted">Atur tugas, simpan catatan, dan jaga fokusmu di satu tempat.</p></div><div className="welcome-code">KD<span> / 01</span></div></section>
        <div className="section-head"><div><h3>Ringkasan hari ini</h3><p>Gambaran singkat aktivitas belajarmu.</p></div><span className="date-tag">MY WORKSPACE</span></div>
        <div className="stats"><article className="stat"><span className="stat-label">TOTAL TUGAS</span><strong>{tasks.length.toString().padStart(2, '0')}</strong><small>Yang ada di daftar</small></article><article className="stat"><span className="stat-label">SELESAI</span><strong>{completed.toString().padStart(2, '0')}</strong><small>Dari tugas yang tercatat</small></article><article className="stat"><span className="stat-label">STATUS FOKUS</span><strong className="status-text">{focusOn ? 'Aktif' : 'Siap'}</strong><small>{focusOn ? 'Sesi fokus berjalan' : 'Mulai saat kamu siap'}</small></article></div>
        <div className="columns"><section className="panel"><div className="panel-head"><div><h3>Tugas yang perlu dikerjakan</h3><p>Checklist sederhana untuk hari ini.</p></div><button className="text-button" onClick={() => setActive('Tugas & Jadwal')}>Lihat semua ↗</button></div><div className="task-list">{tasks.slice(0, 4).map(task => <label className={`task ${task.done ? 'task-done' : ''}`} key={task.id}><input type="checkbox" checked={task.done} onChange={() => setTasks(old => old.map(t => t.id === task.id ? {...t, done: !t.done} : t))}/><span className="task-copy"><b>{task.title}</b><small>{task.subject}</small></span><span className="task-state">{task.done ? 'Selesai' : 'Belum'}</span></label>)}</div></section><section className="panel focus-panel"><div className="panel-head"><div><h3>Focus Mode</h3><p>Kurangi distraksi, satu sesi dulu.</p></div><span className="focus-icon">◷</span></div><div className="timer">25<span>:00</span></div><p className="muted center">25 menit fokus · 5 menit istirahat</p><button className={`primary-button ${focusOn ? 'button-active' : ''}`} onClick={() => setFocusOn(v => !v)}>{focusOn ? 'Akhiri sesi' : 'Mulai sesi fokus'}</button><small className="demo-note">Tampilan awal — timer otomatis menyusul.</small></section></div>
      </>}
      {active === 'Tugas & Jadwal' && <section className="panel page-panel"><div className="panel-head"><div><h3>Daftar tugas</h3><p>Tambahkan tugas dan tandai saat selesai.</p></div><span className="date-tag">{completed}/{tasks.length} SELESAI</span></div><form className="add-task" onSubmit={e => {e.preventDefault(); addTask();}}><input value={newTask} onChange={e => setNewTask(e.target.value)} placeholder="Contoh: PR Bahasa Indonesia" aria-label="Nama tugas"/><button className="primary-button" type="submit">Tambah tugas</button></form><div className="task-list">{tasks.map(task => <label className={`task ${task.done ? 'task-done' : ''}`} key={task.id}><input type="checkbox" checked={task.done} onChange={() => setTasks(old => old.map(t => t.id === task.id ? {...t, done: !t.done} : t))}/><span className="task-copy"><b>{task.title}</b><small>{task.subject}</small></span><span className="task-state">{task.done ? 'Selesai' : 'Belum'}</span></label>)}</div></section>}
      {active === 'Catatan' && <section className="panel page-panel"><div className="panel-head"><div><h3>Catatan cepat</h3><p>Tulis ide atau materi yang perlu diingat.</p></div><span className="date-tag">CATATAN</span></div><textarea className="note-area" value={note} onChange={e => setNote(e.target.value)} placeholder="Mulai tulis catatanmu di sini..."/><p className="muted">Catatan saat ini hanya tersimpan selama halaman ini terbuka. Penyimpanan akun/database akan disambungkan pada tahap berikutnya.</p></section>}
      {active === 'Focus Mode' && <section className="panel page-panel focus-page"><span className="focus-icon large">◷</span><p className="eyebrow">WAKTU UNTUK FOKUS</p><div className="timer big">25<span>:00</span></div><p className="muted">25 menit fokus · 5 menit istirahat</p><button className={`primary-button ${focusOn ? 'button-active' : ''}`} onClick={() => setFocusOn(v => !v)}>{focusOn ? 'Akhiri sesi' : 'Mulai sesi fokus'}</button><p className="demo-note">Timer hitung mundur akan ditambahkan setelah fondasi project siap.</p></section>}
      <footer> KILZ DEV <span>·</span> Dibuat untuk belajar, bukan untuk ribet.</footer>
    </section>
  </main>;
}
