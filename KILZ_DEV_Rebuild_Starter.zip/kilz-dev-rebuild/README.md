# KILZ DEV — Rebuild starter

Starter project for a clean, mobile-first study dashboard using Next.js App Router + TypeScript, prepared for Supabase Auth/database and Vercel deployment.

## Current state
- Minimal dark dashboard and mobile navigation
- Task checklist and add-task interaction (currently local page state only)
- Notes field (currently local page state only)
- Focus Mode visual prototype (timer countdown is not implemented yet)
- Supabase packages and `.env.example` placeholder

## Not yet connected
Authentication, Google OAuth, database persistence, actual countdown timer, calendar reminders, and production database policies are not wired up yet. Do not treat the demo tasks or notes as persistent data.

## Supabase setup (next step)
1. Create a Supabase project.
2. Copy `.env.example` to `.env.local` locally, then fill in `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`.
3. Never put a service-role key in a `NEXT_PUBLIC_` variable or commit secrets to GitHub.
4. Configure Auth redirect URLs after the production Vercel domain exists.

## Run locally
Requires Node.js 20.9+.

```bash
npm install
npm run dev
```

## Deploy
Push project files to a GitHub repository and import that repository in Vercel. Vercel detects Next.js automatically. Configure environment variables in Vercel after Supabase is set up.
